<?php

if ( qode_framework_is_installed( 'elementor' ) ) {
	include_once ELDON_CORE_PLUGINS_PATH . '/elementor/helper.php';
	include_once ELDON_CORE_PLUGINS_PATH . '/elementor/class-eldoncore-elementor-section-handler.php';
}
