<?php

include_once ELDON_CORE_CPT_PATH . '/portfolio/shortcodes/portfolio-list/variations/featured-big/featured-big.php';
