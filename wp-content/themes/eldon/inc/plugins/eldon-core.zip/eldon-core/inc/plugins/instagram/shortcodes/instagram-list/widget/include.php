<?php

include_once ELDON_CORE_PLUGINS_PATH . '/instagram/shortcodes/instagram-list/widget/class-eldoncore-instagram-list-widget.php';
