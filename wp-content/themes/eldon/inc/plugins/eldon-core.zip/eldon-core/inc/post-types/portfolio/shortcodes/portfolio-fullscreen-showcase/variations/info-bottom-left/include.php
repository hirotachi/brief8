<?php

include_once ELDON_CORE_CPT_PATH . '/portfolio/shortcodes/portfolio-fullscreen-showcase/variations/info-bottom-left/info-bottom-left.php';
