<?php

include_once ELDON_CORE_INC_PATH . '/opener-icon/helper.php';
