<?php

include_once ELDON_CORE_INC_PATH . '/header/helper.php';
include_once ELDON_CORE_INC_PATH . '/header/class-eldoncore-header.php';
include_once ELDON_CORE_INC_PATH . '/header/class-eldoncore-headers.php';
include_once ELDON_CORE_INC_PATH . '/header/template-functions.php';
