<?php

include_once ELDON_CORE_PLUGINS_PATH . '/instagram/shortcodes/instagram-list/class-eldoncore-instagram-list-shortcode.php';
