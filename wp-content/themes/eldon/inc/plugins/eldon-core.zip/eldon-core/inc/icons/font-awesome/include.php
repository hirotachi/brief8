<?php

include_once ELDON_CORE_INC_PATH . '/icons/font-awesome/class-eldoncore-font-awesome-pack.php';
