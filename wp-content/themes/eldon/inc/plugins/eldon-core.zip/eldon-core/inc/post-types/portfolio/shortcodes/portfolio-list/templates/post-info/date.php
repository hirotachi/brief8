<span itemprop="dateCreated" class="qodef-e-info-date entry-date published">
	<?php the_time( get_option( 'date_format' ) ); ?>
</span><div class="qodef-info-separator-end"></div>