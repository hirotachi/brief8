<a itemprop="url" class="qodef-e-link" href="<?php echo esc_url( get_term_link( $term_id ) ); ?>"></a>
