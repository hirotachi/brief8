<?php

include_once ELDON_CORE_CPT_PATH . '/class-eldoncore-custom-post-types.php';
