<?php

include_once ELDON_CORE_INC_PATH . '/icons/ionicons/class-eldoncore-ionicons-pack.php';
