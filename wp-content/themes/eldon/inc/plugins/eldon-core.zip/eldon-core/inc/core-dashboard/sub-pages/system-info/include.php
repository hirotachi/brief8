<?php

include_once ELDON_CORE_INC_PATH . '/core-dashboard/sub-pages/system-info/class-eldoncore-dashboard-system-info-page.php';
