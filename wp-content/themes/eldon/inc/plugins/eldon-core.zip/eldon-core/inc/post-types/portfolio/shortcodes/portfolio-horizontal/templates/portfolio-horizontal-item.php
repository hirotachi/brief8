<div class="qodef-plh-item">
	<?php eldon_core_list_sc_template_part( 'post-types/portfolio/shortcodes/portfolio-horizontal', 'post-info/image', '', $params ); ?>
</div>
