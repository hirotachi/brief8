<?php

include_once ELDON_CORE_INC_PATH . '/header/layouts/vertical-minimal/helper.php';
include_once ELDON_CORE_INC_PATH . '/header/layouts/vertical-minimal/class-eldoncore-vertical-minimal-header.php';
include_once ELDON_CORE_INC_PATH . '/header/layouts/vertical-minimal/dashboard/admin/vertical-minimal-header-options.php';
include_once ELDON_CORE_INC_PATH . '/header/layouts/vertical-minimal/dashboard/meta/vertical-minimal-header-meta.php';
