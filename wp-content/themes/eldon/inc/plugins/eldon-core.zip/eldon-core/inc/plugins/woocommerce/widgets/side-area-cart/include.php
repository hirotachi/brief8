<?php

include_once ELDON_CORE_PLUGINS_PATH . '/woocommerce/widgets/side-area-cart/class-eldoncore-woocommerce-side-area-cart-widget.php';
