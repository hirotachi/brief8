<?php eldon_core_get_header_logo_image(); ?>
<?php eldon_core_get_header_widget_area(); ?>
<?php
eldon_core_get_opener_icon_html(
	array(
		'option_name'  => 'fullscreen_menu',
		'custom_class' => 'qodef-fullscreen-menu-opener',
	),
	true
);
