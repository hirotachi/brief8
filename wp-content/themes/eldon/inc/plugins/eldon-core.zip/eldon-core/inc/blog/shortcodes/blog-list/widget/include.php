<?php

include_once ELDON_CORE_INC_PATH . '/blog/shortcodes/blog-list/widget/class-eldoncore-blog-list-widget.php';
