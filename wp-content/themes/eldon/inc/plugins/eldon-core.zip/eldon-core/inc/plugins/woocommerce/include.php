<?php

include_once ELDON_CORE_PLUGINS_PATH . '/woocommerce/class-eldoncore-woocommerce.php';
