<?php

include_once ELDON_CORE_PLUGINS_PATH . '/wpbakery/helper.php';
