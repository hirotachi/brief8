<?php

include_once ELDON_CORE_CPT_PATH . '/portfolio/shortcodes/portfolio-fullscreen-showcase/variations/inverted-color-title/inverted-color-title.php';
