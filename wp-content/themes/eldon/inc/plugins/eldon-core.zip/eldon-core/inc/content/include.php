<?php

include_once ELDON_CORE_INC_PATH . '/content/helper.php';
