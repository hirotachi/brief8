<?php

require_once QODE_FRAMEWORK_INC_PATH . '/icons/class-qodeframeworkicons.php';
require_once QODE_FRAMEWORK_INC_PATH . '/icons/class-qodeframeworkiconpack.php';
